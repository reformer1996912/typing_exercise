<?php 

require '../vendor/autoload.php';

$app = new \Slim\App;
$container = $app->getContainer();

//database
$container['db'] = new PDO('##database_info');

$app->get('/', function($resquest, $response) {
	$connection = $this->get('db');
	$result = $connection->query('select name, marks from rank order by marks desc limit 6');
	$data = [];
	$x = 0;
	while($row=$result->fetch(PDO::FETCH_OBJ)){
        $data[$x] = array($row->name => $row->marks);
        $x++;
    }
	if($data) {
    return $response->withStatus(200)
        ->withHeader('Content-Type', 'application/json')
        ->write(json_encode($data));
	} else { throw new PDOException('No records found');}
});

$app->get('/{name}/{marks}', function($resquest, $response, $args) {
	$connection = $this->get('db');
	$statement = $connection->prepare("insert into rank(name, marks) values (:name, :marks)");
	$statement->bindParam(':name', $args['name']);
	$statement->bindParam(':marks', $args['marks']);
	$statement->execute();
});

$app->run();

 ?>